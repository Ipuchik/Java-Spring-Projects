package co2123.hw1.domain;

public class Product {
    private String packaging;
    private String supplier;
    private String wares;
    private int price;

    public String getPackaging() {
        return packaging;
    }

    public void setPackaging(String packaging) {
        this.packaging = packaging;
    }

    public String getSupplier() {
        return supplier;
    }

    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }

    public String getWares() {
        return wares;
    }

    public void setWares(String wares) {
        this.wares = wares;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
